Всички тестове са на адрес: https://judge.softuni.bg/Contests/#!/List/ByCategory/42/CSharp-OOP-Basics
